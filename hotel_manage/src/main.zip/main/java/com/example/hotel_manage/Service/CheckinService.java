package com.example.hotel_manage.Service;

public interface CheckinService {
}
