package com.example.hotel_manage.Controller;

import com.example.hotel_manage.Pojo.Employee;
import com.example.hotel_manage.Pojo.Result;
import com.example.hotel_manage.Service.EmployeeService;
import com.example.hotel_manage.anno.authority_anno.AdminAnno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class EmployeeController {
    @Autowired
    private HttpServletRequest request;
    @Autowired
    EmployeeService employeeService;
    @PostMapping("/employee")
    @AdminAnno
    Result insertEmployee(Employee employee) {
        employeeService.insertEmployee(employee);
        return Result.success();
    }
    @AdminAnno
    @DeleteMapping("/employee")
    Result deleteEmployee(int id) {
        employeeService.deleteEmployee(id);
        return Result.success();
    }
    @PostMapping("/emp/update")
    Result updateEmployee(Employee employee) {
        employeeService.updateEmployee(employee);
        return Result.success();
    }
}
