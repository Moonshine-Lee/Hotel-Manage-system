package com.example.hotel_manage.Controller;

import com.example.hotel_manage.Pojo.Bill;
import com.example.hotel_manage.Pojo.Result;
import com.example.hotel_manage.Service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class BillController {
    @Autowired
    BillService billService;
    @PostMapping("/bill")
    public Result createBill(@RequestBody Bill bill) {
        billService.createBill(bill,false);
        return Result.success();
    }

    //订单成功支付后的回调函数
    @PostMapping()
    public Result billPaymentRecall(){
        return Result.success();
    }

    //小额订单可以不进行异步校验



}
