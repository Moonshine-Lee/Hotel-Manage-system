package com.example.hotel_manage.Mapper;

import com.example.hotel_manage.Pojo.Employee;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Delete;

@Mapper
public interface EmployeeMapper {

    @Insert("INSERT INTO employee (password, name, username, type, phone_number) " +
            "VALUES (#{employee.password}, #{employee.name}, #{employee.username}, #{employee.type}, #{employee.phoneNumber})")
    int insert(@Param("employee") Employee employee);

    @Select("SELECT * FROM employee WHERE employee_id = #{id}")
    Employee getById(@Param("id") Integer id);

    @Select("SELECT * FROM employee WHERE username = #{username}")
    Employee getByUsername(@Param("username") String username);


    @Update("UPDATE employee SET password=#{employee.password}, name=#{employee.name}, username=#{employee.username}, " +
            "type=#{employee.type}, phone_number=#{employee.phoneNumber} " +
            "WHERE employee_id = #{employee.employeeId}")
    int update(@Param("employee") Employee employee);


    @Delete("DELETE FROM employee WHERE employee_id = #{id}")
    int deleteById(@Param("id") Integer id);

    @Select("select * from employee where username=#{username} and password=#{password}")
    Employee login(@Param("username") String username,@Param("password") String password);
}
