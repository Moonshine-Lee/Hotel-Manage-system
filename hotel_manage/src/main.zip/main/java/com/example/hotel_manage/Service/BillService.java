package com.example.hotel_manage.Service;

import com.example.hotel_manage.Pojo.Bill;

public interface BillService {
    //现实业务中，对于支付的生成 可以通过读取传入数据/ api自动唤起 等方式 ，
    void createBill(Bill bill,boolean check);
}
