package com.example.hotel_manage.Service.impl;

import com.example.hotel_manage.Mapper.BillMapper;
import com.example.hotel_manage.Mapper.OrderMapper;
import com.example.hotel_manage.Pojo.Bill;
import com.example.hotel_manage.Pojo.Enum.BillType;
import com.example.hotel_manage.Pojo.Order;
import com.example.hotel_manage.Pojo.RoomFront;
import com.example.hotel_manage.Service.BillService;
import com.example.hotel_manage.Service.OrderService;
import com.example.hotel_manage.Service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    RoomService roomService;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private BillMapper billMapper;
    @Autowired
    private BillService billService;


    @Override
    public List<Order> getAllOrders() {
        return List.of();
    }

    @Override
    public Order getOrderById(int id) {
        return orderMapper.findById(id);
    }

    //create order不需要传入房间号，房间号将被分配
    @Override
    public Order createOrder(Order order) {


        List<RoomFront> availableRoom = roomService.findAvailableRoom(order.getOrderDate(), order.getOrderDays());
        String roomType = order.getRoomType();
        for (RoomFront room : availableRoom) {
            if (room.getRoomType().equals(roomType)) {
                roomService.setRoomUnavailable(room.getRoomId(), order.getOrderDate(), order.getOrderDays());
                order.setRoomId(room.getRoomId());
                order.setSuccessPaid(false);
                orderMapper.insert(order);

                float price = room.getPrice() * order.getOrderDays();

                Bill bill = new Bill();
                bill.setOrderId(order.getOrderId());
                bill.setBillType(BillType.onlineOrder);
                bill.setAmount(price);

                //billService将启动异步交互线程 以查询bill的支付状态,并设置order信息
                billService.createBill(bill,true);


                return order;


            }
        }
        return null;

    }

    @Override
    public void updateOrder(Order order) {
        orderMapper.update(order);
        return;

    }

    @Override
    public void deleteOrder(int id) {
        orderMapper.deleteById(id);
        return;
    }

    //此处用作前台显示当日可办理入住的order
    @Override
    public List<Order> getOrderByDate(LocalDate date) {
        return orderMapper.findOrderByDate(date);
    }


    @Override
    public Order getOrderByRoomIdAndDate(String roomId, LocalDate date) {
        return orderMapper.findOrderByRoomIdAndDate(roomId, date);
    }
}
