package com.example.hotel_manage.Mapper;

import com.example.hotel_manage.Pojo.Bill;
import org.apache.ibatis.annotations.*;

@Mapper
public interface BillMapper {

    @Insert("INSERT INTO bill (bill_type,order_id,checkin_id,paying_reference ,amount, payment_method, payment_time) " +
            "VALUES (#{bill.billType},#{bill.order_id},#{bill.checkinId},#{bill.paddddddddde3},#{bill.amount}, #{bill.paymentMethod}, #{bill.paymentTime}, #{bill.receivingAccount}, #{bill.payingAccount})")
    @Options(useGeneratedKeys = true,keyProperty = "bill.billId")
    int insert(@Param("bill") Bill bill);

    @Select("SELECT * FROM bill WHERE bill_id = #{id}")
    Bill findById(@Param("id") Integer id);

    int update(@Param("bill") Bill bill);

    @Delete("DELETE FROM bill WHERE bill_id = #{id}")
    int deleteById(@Param("id") Integer id);



}
