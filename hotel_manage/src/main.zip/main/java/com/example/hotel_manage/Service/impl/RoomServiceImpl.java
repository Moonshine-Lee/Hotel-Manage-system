package com.example.hotel_manage.Service.impl;

import com.example.hotel_manage.Exception.RoomUnavailableException;
import com.example.hotel_manage.Mapper.CheckinMapper;
import com.example.hotel_manage.Mapper.OrderAchieveMapper;
import com.example.hotel_manage.Mapper.OrderMapper;
import com.example.hotel_manage.Mapper.RoomMapper;
import com.example.hotel_manage.Pojo.Checkin;
import com.example.hotel_manage.Pojo.Enum.RoomStatus;
import com.example.hotel_manage.Pojo.Order;
import com.example.hotel_manage.Pojo.RoomFront;
import com.example.hotel_manage.Service.RoomService;
import com.example.hotel_manage.Utils.RoomStringUtils;
import com.example.hotel_manage.anno.authority_anno.ReceptionistAnno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.hotel_manage.Pojo.RoomSql;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {
    @Autowired
    RoomMapper roomMapper;
    @Autowired
    OrderAchieveMapper orderAchieveMapper;
    @Autowired
    RoomStringUtils roomStringUtils;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private CheckinMapper checkinMapper;

    @Override
    @ReceptionistAnno
    public RoomFront findById(String roomId) {
        RoomSql roomSql = roomMapper.findById(roomId);
        RoomFront roomFront = roomStringUtils.sqlToFront(roomSql);
        return roomFront;
    }

    //针对i小于90的情况，查找是否可用
    @ReceptionistAnno
    @Override
    public Boolean checkAvailability_in_i_days(String roomId, Integer i) {
        RoomSql roomSql = roomMapper.findById(roomId);
        if (!(roomSql.getRoomStatus() == RoomStatus.available)) {
            return false;
        }
        RoomFront roomFront = roomStringUtils.sqlToFront(roomSql);
        for (int j = 0; j < i; j++) {
            if (!roomFront.getIsAvailableIn90Days()[j]) {
                return false;
            }
        }

        return true;
    }


    @ReceptionistAnno
    @Override
    public List<RoomFront> findAllRoom() {
        List<RoomSql> roomSqlList = roomMapper.findAllRooms();
        List<RoomFront> roomFrontList = new ArrayList<>();
        for (RoomSql roomSql : roomSqlList) {
            roomFrontList.add(roomStringUtils.sqlToFront(roomSql));
        }
        return roomFrontList;
    }

    @Override
    public void setRoomUnavailable(String roomId, LocalDate date, Integer nDays) {
        LocalDate now = LocalDate.now();
        long days = ChronoUnit.DAYS.between(date, now);
        if (days >= 90)
            return;
        RoomSql roomById = roomMapper.findRoomById(roomId);
        Boolean[] booleans = roomStringUtils.StrToBool(roomById.getIsAvailableIn90Days());
        for (int j = (int) days; j < days + nDays && j < 90; j++) {
            booleans[j] = false;
        }
        roomById.setIsAvailableIn90Days(roomStringUtils.boolToString(booleans));
        roomMapper.update(roomById);
    }

    @ReceptionistAnno
    @Override
    public List<RoomFront> findAvailableRoom(LocalDate date) {
        LocalDate now = LocalDate.now();
        long days = ChronoUnit.DAYS.between(date, now);
        //如果超过90天（串最大范围）则order表和room表联查
        if (days >= 90) {
            List<String> allRoomIds = roomMapper.findAllRoomIds();
            List<String> idsList = orderMapper.findOrderIdByDate(date);
            List<String> availableIds = new ArrayList<>();
            for (String roomId : allRoomIds) {
                if (!idsList.contains(roomId)) {
                    availableIds.add(roomId);
                }
            }
            List<RoomSql> roomSqlList = new ArrayList<>();
            for (String availableId : availableIds) {
                roomSqlList.add(roomMapper.findRoomById(availableId));
            }
            List<RoomFront> roomFrontList = new ArrayList<>();
            for (RoomSql roomSql : roomSqlList) {
                roomFrontList.add(roomStringUtils.sqlToFront(roomSql));
            }
            return roomFrontList;
        } else {
            List<RoomSql> allRooms = roomMapper.findAllRooms();
            List<RoomFront> roomFrontList = new ArrayList<>();
            for (RoomSql roomSql : allRooms) {
                if (roomSql.getIsAvailableIn90Days().charAt((int) days) == '1')
                    roomFrontList.add(roomStringUtils.sqlToFront(roomSql));
            }
            return roomFrontList;
        }
    }

    @ReceptionistAnno
    @Override
    public void setAvailableInNDays(String roomId, Integer nDays) {
        RoomSql byId = roomMapper.findById(roomId);
        Boolean[] booleans = roomStringUtils.StrToBool(byId.getIsAvailableIn90Days());
        for (int i = 0; i <= nDays; i++) {
            booleans[i] = true;
        }
        byId.setIsAvailableIn90Days(roomStringUtils.boolToString(booleans));
        roomMapper.update(byId);
    }

    @ReceptionistAnno
    @Override
    public List<RoomFront> findAvailableRoom(LocalDate date, Integer continue_time) {
        List<RoomFront> l1 = findAvailableRoom(date);
        for (int i = 1; i <= continue_time; i++) {
            List<RoomFront> l2 = findAvailableRoom(date.plusDays(1));
            l1.retainAll(l2);
        }
        return l1;
    }

    //checkIn 首先判断是否可用，然后设置未来n天均不可用
    //应设计并发机制（后续补充）
    //在checkin中应实现搬表（把实现了的order 搬到新的地方）
    @ReceptionistAnno
    @Override
    public Boolean checkin(Boolean withorder, String roomId, Integer time, String indentityCard, String phone, float payment_amount) {
        RoomSql roomSql = roomMapper.findById(roomId);

        if (!checkAvailability_in_i_days(roomId, time)) {
            if(!withorder){
                throw new RoomUnavailableException("该房间已经被他人入住");
            }
            Order order = orderMapper.findOrderByRoomIdAndDate(roomId, LocalDate.now());
            Checkin identity_checkin = checkinMapper.findByCustomerIdentityCardAndDate(indentityCard, LocalDate.now());
            if (identity_checkin != null && !identity_checkin.getCheckInStatus().equals("checkout")) {
                throw new RoomUnavailableException("该身份证已经办理过入住，不可重复办理");
            }
            if (order.getOrderDays() < time) {
                throw new RoomUnavailableException("入住申请超过订单申请的时常，拒绝入住");
            }
            if (order == null) {
                throw new RoomUnavailableException("提供信息有误，查询不到预定订单");
            }
            if (!order.getPhoneNumber().equals(phone)) {
                throw new RoomUnavailableException("手机号与订单不符,请提供预定订单时的手机号");
            }
            if (!(roomSql.getRoomStatus() == RoomStatus.available)) {
                throw new RoomUnavailableException("房间尚未退房，无法入住");
            }
        }

        Boolean[] booleans = roomStringUtils.StrToBool(roomSql.getIsAvailableIn90Days());
        for (int i = 0; i < time; i++) {
            booleans[i] = false;
        }
        String str_afterUpdate = roomStringUtils.boolToString(booleans);
        roomMapper.checkIn(roomId, str_afterUpdate);
        Checkin checkin = new Checkin(roomId, time, indentityCard, phone, payment_amount);
        checkinMapper.insert(checkin);
        return true;
    }

    //提前退房的话，则设置后几天的该room均为可用状态
    @ReceptionistAnno
    @Override
    public Boolean checkout(String roomId) {
        Checkin checkin = checkinMapper.findByRoomIdAndDate(roomId, LocalDate.now());
        checkinMapper.checkOut(checkin.getCheckinId(), LocalDateTime.now());
        Order orderByRoomIdAndDate = orderMapper.findOrderByRoomIdAndDate(roomId, LocalDate.now());
        orderAchieveMapper.insert(orderByRoomIdAndDate);
        orderMapper.deleteById(orderByRoomIdAndDate.getOrderId());
        roomMapper.checkout(roomId);
        //后续再设计是否提前退房的判断逻辑

        return true;
    }

    public void clean(String roomId) {
        RoomSql roomById = roomMapper.findRoomById(roomId);
        if(!(roomById.getRoomStatus().equals(RoomStatus.cleaning))) {
            throw new RoomUnavailableException("房间未退房，不可打扫");
        }
    }

    public List<RoomFront> findRoomeToBeCleaned() {
        List<RoomSql> allRooms = roomMapper.findAllRooms();
        List<RoomFront> roomFrontList = new ArrayList<>();
        for (RoomSql roomSql : allRooms) {
            if(roomSql.getRoomStatus().equals(RoomStatus.cleaning)) {
                roomFrontList.add(roomStringUtils.sqlToFront(roomSql));
            }
        }
        return roomFrontList;
    }
}