package com.example.hotel_manage.Mapper;

import com.example.hotel_manage.Pojo.RoomFront;
import com.example.hotel_manage.Pojo.RoomSql;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

@Mapper
public interface RoomMapper {

    @Insert("INSERT INTO room (room_id, price, room_type, is_available_in90days, description) " +
            "VALUES (#{room.roomId}, #{room.price}, #{room.roomType}, #{room.isAvailableIn90Days}, #{room.description})")
    int insert(@Param("room") RoomSql room);

    @Select("SELECT * FROM room WHERE room_id = #{id}")
    RoomSql findById(@Param("id") String id);

    @Update("UPDATE room SET price=#{room.price}, room_type=#{room.roomType}, is_available_in90days=#{room.isAvailableIn90Days}, " +
            "description=#{room.description} WHERE room_id = #{room.roomId}")
    int update(@Param("room") RoomSql room);

    @Delete("DELETE FROM room WHERE room_id = #{id}")
    int deleteById(@Param("id") String id);

    @Select("select * from room")
    List<RoomSql> findAllRooms();

    @Select("select room_id from room")
    List<String> findAllRoomIds();

    @Select("select * from room where room_id=#{id}")
    RoomSql findRoomById(@Param("id") String id);

    List<RoomSql> getRoomSqlListByIds(List<String> ids);

    @Update("update room set is_available_in90days=#{available},room_status = 'occupied'  where room_id=#{id}")
    void checkIn(@Param("available") String isAvailableIn90Days,@Param("id") String id);
    @Update("update room set room_status='cleaning' where room_id=#{roomId}")
    void checkout(@Param("roomId") String roomeId);
}
