package com.example.hotel_manage.Pojo.Enum;

public enum OrderType {
    xiecheng,
    qunaer,
    dazhongdianping,
    phone
}
