package com.example.hotel_manage.Mapper;

import com.example.hotel_manage.Pojo.Checkin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Delete;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Mapper
public interface CheckinMapper {

    @Insert("INSERT INTO check_in (room_id, customer_identitycard, check_in_time, check_in_status, check_out_time, payment_amount) " +
            "VALUES (#{checkIn.roomId}, #{checkIn.customerIdentityCard}, #{checkIn.checkInTime}, #{checkIn.checkInStatus}, #{checkIn.checkOutTime}, #{checkIn.paymentAmount})")
    int insert(@Param("checkIn") Checkin checkIn);

    @Select("SELECT * FROM check_in WHERE checkin_id = #{id}")
    Checkin findById(@Param("id") Integer id);

    @Update("UPDATE check_in SET room_id=#{checkIn.roomId}, customer_identitycard=#{checkIn.customerIdentityCard}, check_in_time=#{checkIn.checkInTime}, " +
            "check_in_status=#{checkIn.checkInStatus}, check_out_time=#{checkIn.checkOutTime}, payment_amount=#{checkIn.paymentAmount} " +
            "WHERE checkin_id = #{checkIn.checkinId}")
    int update(@Param("checkIn") Checkin checkIn);

    @Delete("DELETE FROM check_in WHERE checkin_id = #{id}")
    int deleteById(@Param("id") Integer id);
    @Select("select * from check_in where customer_identitycard=#{customerIdentityCard} and #{date} between check_in_time and date_add(check_in_time,days)")
    Checkin findByCustomerIdentityCardAndDate(@Param("customerIdentityCard") String customerIdentityCard,@Param("date") LocalDate date);

    @Select("select * from check_in where room_id=#{roomId} and #{date} between check_in_time and date_add(check_in_time,days)")
    Checkin findByRoomIdAndDate(@Param("roomId") String roomId, @Param("date") LocalDate date);
    @Update("update check_in set check_in_status='checkout' and check_out_time=#{checkoutTime} where checkin_id=#{checkinId}")
    void checkOut(@Param("checkinId") Integer checkinId,@Param("checkoutTime")  LocalDateTime checkoutTime);
}
