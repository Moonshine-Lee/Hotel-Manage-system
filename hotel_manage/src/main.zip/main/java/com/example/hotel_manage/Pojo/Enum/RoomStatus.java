package com.example.hotel_manage.Pojo.Enum;

public enum RoomStatus {
    available,
    cleaning,
    occupied
}
