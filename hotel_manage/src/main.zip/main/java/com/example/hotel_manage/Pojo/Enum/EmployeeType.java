package com.example.hotel_manage.Pojo.Enum;

public enum EmployeeType {
    admin,
    receptionist,
    housekeeper
}
