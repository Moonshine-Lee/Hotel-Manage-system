package com.example.hotel_manage.Controller;

import com.example.hotel_manage.Pojo.Order;
import com.example.hotel_manage.Pojo.Result;
import com.example.hotel_manage.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController("/order")
public class OrderController {
    @Autowired
    OrderService orderService;

    @PostMapping("/order")
    public Result insertOrder(@RequestBody Order order) {
        Order order1 = orderService.createOrder(order);

        if(order1 != null) {
            return Result.success(order1);
        }
        else return Result.error("创建失败,房型或日期不可用");
    }

    @PostMapping("order/delete")
    public Result deleteOrder(@RequestBody Order order) {
        orderService.deleteOrder(order.getOrderId());
        return Result.success();
    }
    @PostMapping("/order/bydate")
    public Result getOrderByDate(@RequestBody LocalDate localDate) {
        List<Order> orderByDate = orderService.getOrderByDate(localDate);
        return Result.success(orderByDate);
    }

}
