package com.example.hotel_manage.Controller;

import com.example.hotel_manage.Exception.RoomUnavailableException;
import com.example.hotel_manage.Pojo.Result;
import com.example.hotel_manage.Service.RoomService;
import com.example.hotel_manage.anno.authority_anno.ReceptionistAnno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;
    //返回room可用状态会返回一个长度为90的布尔型维数组
    @ReceptionistAnno
    @GetMapping("/{roomId}")
    public Result findById(@PathVariable String roomId) {
       return Result.success(roomService.findById(roomId));
    }
    @PostMapping("/checkin")
    public Result checkin(@RequestBody Boolean withOrder,@RequestBody String roomId,@RequestBody Integer time,@RequestBody String indentityCard,@RequestBody String phone,@RequestBody float payment_amount)
    {
        try {
            roomService.checkin(withOrder,roomId,time,indentityCard,phone,payment_amount);
        }
        catch (RoomUnavailableException e){
            return Result.error(e.getMessage());
        }

        return Result.success();
    }

    @GetMapping("/clean")
    public Result getRoomToBeCleaned(){
        return Result.success(roomService.findRoomeToBeCleaned());
    }

    @PostMapping("/clean")
    public Result cleanRoom(@RequestBody String roomId){
        roomService.clean(roomId);
        return Result.success();
    }
    @PostMapping("/checkout")
    public Result checkout(@RequestBody String roomId){
        roomService.checkout(roomId);
        return Result.success();
    }
    @PostMapping("/date")
    public Result findAvailableRoom(@RequestBody LocalDate date,@RequestBody Integer continue_time){
        if(continue_time == null){
            return Result.success(roomService.findAvailableRoom(date));
        }
        else
            return Result.success(roomService.findAvailableRoom(date,continue_time));
    }

}

