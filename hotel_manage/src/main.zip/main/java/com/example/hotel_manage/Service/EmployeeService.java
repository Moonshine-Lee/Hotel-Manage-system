package com.example.hotel_manage.Service;

import com.example.hotel_manage.Pojo.Employee;

public interface EmployeeService {
    
    Employee login(String username, String password);

    void insertEmployee(Employee employee);

    void updateEmployee(Employee employee);

    void deleteEmployee(int id);
}
